Page({
    data: {
        //输入变量
        // get:"",
        send:"",
        capacity:"",
        //输出结果变量
        resultYear:"",
        resultMonth:"",
        resultDay:"",
        resultHour:"",
        //自定义内置变量，已经初始化过
        sendI: "20",//数据发送电流，单位mA
        sendTime: "40",//数据发送时长，单位s
        getI: "100",//水位采集电流,单位mA
        getTime: "10",//数据采集时长，单位s
        // restI: "40",//平均休息电流，单位μA
        speedI: "30",//流速采集电流，单位mA
        speedTime: "20",//流速采集时长，单位s
    },
    result:null,
    
    //获取用户输入值
      // getT: function(res){
      //   // console.log("输入的值为："+res.detail.value);//打印输入的值
      //   this.setData({
      //       get: res.detail.value//赋值给get
      //   })
      // },
      sendT: function(res){
        this.setData({
            send: res.detail.value//赋值给send
        })
      },
      capacityT: function(res){
        this.setData({
            capacity:res.detail.value//赋值给capacity
        })
      },
      //获取自定义内置参数输入值
      getI_T: function(res){
        this.setData({
          getI:res.detail.value//赋值给getI
        })
      },
      sendI_T: function(res){
        this.setData({
          sendI:res.detail.value//赋值给sendI
        })
      },
      // restI_T: function(res){
      //   this.setData({
      //     restI:res.detail.value//赋值给restI
      //   })
      // },
      getTime_T: function(res){
        this.setData({
          getTime:res.detail.value//赋值给getTime
        })
      },
      sendTime_T: function(res){
        this.setData({
          sendTime:res.detail.value//赋值给sendTime
        })
      },
      speedI_T: function(res){
        this.setData({
          speedI:res.detail.value//赋值给speedI
        })
      },
      speedTime_T: function(res){
        this.setData({
          speedTime:res.detail.value//赋值给speedTime
        })
      },
      //按钮点击事件
      but1: function(res){
        //需要用户输入的参数
          // var get = Number(this.data.get)
          var send = Number(this.data.send)
          var capacity = Number(this.data.capacity)
          //用户可以自定义更改的内置参数
          var getI = Number(this.data.getI)
          var sendI = Number(this.data.sendI)
          // var restI = Number(this.data.restI)
          var getTime = Number(this.data.getTime)
          var sendTime = Number(this.data.sendTime)
          var speedI = Number(this.data.speedI)
          var speedTime = Number(this.data.speedTime)
        //计算和输出
        //计算小时
          this.result = capacity * 3600 / (((3600 / (getTime + speedTime)) * (getI * getTime + speedI * speedTime)) + (60 / send) * sendI * sendTime)
          this.setData({resultHour: this.result + ""})
          //计算天
          this.result = this.result / 24
          this.setData({resultDay: this.result + ""})
          //计算月
          this.result = this.result / 30
          this.setData({resultMonth: this.result + ""})
          //计算年
          this.result = this.result / 12
          this.setData({resultYear: this.result + ""})
      }
})